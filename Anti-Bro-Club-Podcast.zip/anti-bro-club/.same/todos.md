# Anti Bro Club Landing Page - TODOs

## Completed
- [x] Create project with Next.js + shadcn
- [x] Design hero section with bold typography
- [x] Create About the Show section
- [x] Create Who We're Looking For section
- [x] Create What to Expect section
- [x] Build application form with all fields
- [x] Set up Google Sheets integration placeholder
- [x] Create Google Sheets setup documentation

## Pending (User Action Required)
- [ ] Add Google Apps Script URL for form submissions (see GOOGLE_SHEETS_SETUP.md)
- [ ] Optional: Add host photo when provided
- [ ] Optional: Add podcast platform links when available
- [ ] Optional: Add episode length/platform details

## Project Ready for Deployment
The landing page is complete and ready to connect to Google Sheets!
